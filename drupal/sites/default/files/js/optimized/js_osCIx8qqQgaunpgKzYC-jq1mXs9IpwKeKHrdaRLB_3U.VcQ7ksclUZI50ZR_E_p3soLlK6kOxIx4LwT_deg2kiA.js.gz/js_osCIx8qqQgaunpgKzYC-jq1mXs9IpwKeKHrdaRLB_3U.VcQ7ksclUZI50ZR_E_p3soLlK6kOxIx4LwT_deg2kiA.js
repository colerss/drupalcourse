/* Source and licensing information for the line(s) below can be found at http://localhost/drupal/core/assets/vendor/jquery.ui/ui/safe-blur-min.js. */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.ui.safeBlur=function(n){n&&"body"!==n.nodeName.toLowerCase()&&e(n).trigger("blur")}}));
//# sourceMappingURL=safe-blur-min.js.map
/* Source and licensing information for the above line(s) can be found at http://localhost/drupal/core/assets/vendor/jquery.ui/ui/safe-blur-min.js. */